/**
 * ============================================
 * 파일명: LikeService.java
 * 작성일: 2024-12-02
 * 작성자: 선우
 * 설명: 좋아요 관련 비즈니스 로직 인터페이스
 *      - 좋아요 추가/취소 기능
 *      - 좋아요 통계 및 목록 조회
 * ============================================
 */
package com.music.service;

import java.util.List;
import com.music.domain.SongVO;

public interface LikeService {
    
    // 좋아요 토글 (좋아요 되어있으면 취소, 안되어있으면 추가)
    public boolean toggleLike(Integer userId, Integer songId);
    
    // 좋아요 여부 확인
    public boolean isLiked(Integer userId, Integer songId);
    
    // 음원의 총 좋아요 수
    public int getLikeCount(Integer songId);
    
    // 사용자가 좋아요한 음원 목록
    public List<SongVO> getLikedSongs(Integer userId);
    
    // 좋아요 많은 순으로 인기 음원 조회
    public List<SongVO> getTopLikedSongs(int limit);
}