/**
 * ============================================
 * 파일명: SongService.java
 * 작성일: 2024-11-30 (수정: 2024-12-02)
 * 작성자: 선우
 * 설명: 음원 관련 비즈니스 로직 인터페이스
 *      - 음원 CRUD 및 검색
 *      - 페이징 처리
 *      - 재생 횟수 관리
 * ============================================
 */
package com.music.service;

import java.util.List;
import com.music.domain.SongVO;
import com.music.domain.Criteria;

public interface SongService {
	
	// 전체 음원 목록 조회
	public List<SongVO> getAllSongs();
	
	// 페이징된 음원 목록 조회
	public List<SongVO> getSongsWithPaging(Criteria cri);
	
	// 전체 음원 개수 (페이징 계산용)
	public int getTotalCount();
	
	// 음원 상세 정보 조회
	public SongVO getSongById(int songId);
	
	// 새 음원 등록
	public void registerSong(SongVO song);
	
	// 음원 정보 수정
	public void updateSong(SongVO song);
	
	// 음원 삭제
	public void deleteSong(int songId);
	
	// 음원 검색 (제목/아티스트/앨범)
	public List<SongVO> searchSongs(String keyword);
	
	// 재생 횟수 증가
	public void playSong(int songId);
	
	// 인기 음원 Top 10 (재생 횟수 기준)
	public List<SongVO> getTopSongs();
}