/**
 * ============================================
 * 파일명: PostVO.java
 * 작성일: 2024-11-28
 * 작성자: 선우
 * 설명: 게시물 정보를 담는 VO 클래스
 *      - posts 테이블과 매핑
 *      - 게시판 게시글 데이터 관리
 *      - 카테고리별 분류 지원
 * ============================================
 */
package com.music.domain;

import java.sql.Timestamp;
import lombok.Data;

@Data
public class PostVO {
	private int postId;           // 게시물 ID (PK)
	private int userId;           // 작성자 ID (FK)
	private String category;      // 카테고리 (자유게시판, 음악추천 등)
	private String title;         // 제목
	private String content;       // 내용
	private int viewCount;        // 조회수
	private Timestamp createdAt;  // 작성일
	
	// 조인용 추가 필드
	private String username;      // 작성자 이름 (users 테이블 조인)
}