/**
 * ============================================
 * 파일명: CommentVO.java
 * 작성일: 2024-11-28
 * 작성자: 선우
 * 설명: 댓글 정보를 담는 VO (Value Object) 클래스
 *      - comments 테이블과 매핑
 *      - 게시글의 댓글 데이터 관리
 * ============================================
 */
package com.music.domain;

import java.sql.Timestamp;
import lombok.Data;

@Data
public class CommentVO {
	private int commentId;        // 댓글 ID (PK)
	private int postId;           // 게시물 ID (FK)
	private int userId;           // 작성자 ID (FK)
	private String content;       // 댓글 내용
	private Timestamp createdAt;  // 작성일
	
	// 조인용 추가 필드
	private String username;      // 작성자 이름
}