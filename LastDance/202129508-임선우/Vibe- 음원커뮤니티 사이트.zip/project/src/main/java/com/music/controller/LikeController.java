/**
 * ============================================
 * 파일명: LikeController.java
 * 작성일: 2024-12-10
 * 작성자: 선우
 * 설명: 좋아요 기능 관련 요청을 처리하는 컨트롤러
 *      - 좋아요 추가/취소 (토글)
 *      - 좋아요 상태 확인
 * ============================================
 */
package com.music.controller;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.music.domain.UserVO;
import com.music.service.LikeService;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/like")
public class LikeController {
	
	@Autowired
	private LikeService likeService;
	
	// 좋아요 추가/취소 (AJAX)
	@PostMapping(value = "/toggle", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String toggleLike(@RequestParam("songId") int songId, HttpSession session) {
		log.info("좋아요 토글: songId=" + songId);
		
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		
		// 로그인 체크
		if (loginUser == null) {
			return "{\"success\": false, \"message\": \"로그인이 필요합니다\"}";
		}
		
		try {
			// 좋아요 추가/취소 처리
			boolean isLiked = likeService.toggleLike(loginUser.getUserId(), songId);
			int likeCount = likeService.getLikeCount(songId);
			
			return String.format("{\"success\": true, \"isLiked\": %b, \"likeCount\": %d}", 
			                     isLiked, likeCount);
		} catch (Exception e) {
			log.error("좋아요 토글 실패", e);
			return "{\"success\": false, \"message\": \"오류가 발생했습니다\"}";
		}
	}
	
	// 좋아요 상태 확인 (AJAX)
	@PostMapping(value = "/check", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String checkLike(@RequestParam("songId") int songId, HttpSession session) {
		log.info("좋아요 확인: songId=" + songId);
		
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		
		if (loginUser == null) {
			return "{\"success\": false, \"isLiked\": false}";
		}
		
		try {
			boolean isLiked = likeService.isLiked(loginUser.getUserId(), songId);
			return String.format("{\"success\": true, \"isLiked\": %b}", isLiked);
		} catch (Exception e) {
			log.error("좋아요 확인 실패", e);
			return "{\"success\": false, \"isLiked\": false}";
		}
	}
}