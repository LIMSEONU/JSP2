/**
 * ============================================
 * 파일명: CommentMapper.java
 * 작성일: 2024-11-29
 * 작성자: 선우
 * 설명: 댓글 관련 데이터베이스 처리 매퍼 인터페이스
 *      - MyBatis를 통한 댓글 CRUD 작업
 *      - CommentMapper.xml과 연동
 * ============================================
 */
package com.music.mapper;

import java.util.List;
import com.music.domain.CommentVO;

public interface CommentMapper {
	
	// 특정 게시물의 댓글 목록 조회
	public List<CommentVO> getCommentsByPostId(int postId);
	
	// 댓글 작성
	public void insertComment(CommentVO comment);
	
	// 댓글 수정
	public void updateComment(CommentVO comment);
	
	// 댓글 삭제
	public void deleteComment(int commentId);
}