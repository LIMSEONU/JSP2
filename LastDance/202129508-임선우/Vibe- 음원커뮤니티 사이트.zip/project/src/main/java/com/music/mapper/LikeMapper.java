package com.music.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.music.domain.SongVO;

/**
 * ============================================
 * 파일명: LikeMapper.java
 * 작성일: 2024-12-02
 * 작성자: 선우
 * 설명: 좋아요 관련 데이터베이스 처리 매퍼 인터페이스
 *      - MyBatis를 통한 좋아요 기능 구현
 *      - LikeMapper.xml과 연동
 * ============================================
 */
public interface LikeMapper {
    
    // 좋아요 추가
    void insert(@Param("userId") Integer userId, @Param("songId") Integer songId);
    
    // 좋아요 취소
    void delete(@Param("userId") Integer userId, @Param("songId") Integer songId);
    
    // 좋아요 여부 확인 (1: 좋아요, 0: 안함)
    int isLiked(@Param("userId") Integer userId, @Param("songId") Integer songId);
    
    // 음원의 총 좋아요 수
    int getLikeCount(@Param("songId") Integer songId);
    
    // 사용자가 좋아요한 음원 목록 조회
    List<SongVO> getLikedSongs(@Param("userId") Integer userId);
    
    // 좋아요 많은 순으로 인기 음원 조회
    List<SongVO> getTopLikedSongs(@Param("limit") int limit);
}