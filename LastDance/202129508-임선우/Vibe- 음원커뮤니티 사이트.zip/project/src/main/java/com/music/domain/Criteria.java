/**
 * ============================================
 * 파일명: Criteria.java
 * 작성일: 2024-12-02
 * 작성자: 선우
 * 설명: 페이징 처리를 위한 기준 정보 VO
 *      - 현재 페이지 번호와 페이지당 게시물 수 관리
 *      - MySQL LIMIT 절을 위한 offset 계산
 * ============================================
 */
package com.music.domain;

import lombok.Data;

@Data
public class Criteria {
    private int pageNum;     // 현재 페이지 번호
    private int amount;      // 한 페이지당 게시물 수
    
    // 기본 생성자 (1페이지, 10개씩)
    public Criteria() {
        this(1, 10);
    }
    
    public Criteria(int pageNum, int amount) {
        this.pageNum = pageNum;
        this.amount = amount;
    }
    
    // MySQL LIMIT 시작 위치 계산 (OFFSET)
    public int getOffset() {
        return (pageNum - 1) * amount;
    }
}