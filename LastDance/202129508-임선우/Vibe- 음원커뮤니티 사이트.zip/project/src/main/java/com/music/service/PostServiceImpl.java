/**
 * ============================================
 * 파일명: PostServiceImpl.java
 * 작성일: 2024-11-30
 * 작성자: 선우
 * 설명: 게시물 관련 비즈니스 로직 구현 클래스
 *      - PostService 인터페이스 구현
 *      - 게시글/댓글 CRUD 처리
 *      - 트랜잭션 관리
 * ============================================
 */
package com.music.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.music.domain.CommentVO;
import com.music.domain.Criteria;
import com.music.domain.PostVO;
import com.music.mapper.CommentMapper;
import com.music.mapper.PostMapper;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class PostServiceImpl implements PostService {
	
	@Autowired
	private PostMapper postMapper;
	
	@Autowired
	private CommentMapper commentMapper;
	
	@Override
	public List<PostVO> getAllPosts() {
		log.info("전체 게시물 목록 조회");
		return postMapper.getAllPosts();
	}
	
	@Override
	public List<PostVO> getPostsByCategory(String category) {
		log.info("카테고리별 게시물 조회: " + category);
		return postMapper.getPostsByCategory(category);
	}
	
	// 게시물 상세 조회 (조회수 증가 포함)
	@Transactional  // 조회수 증가와 게시물 조회를 하나의 트랜잭션으로 처리
	@Override
	public PostVO getPostById(int postId) {
		log.info("게시물 상세 조회: " + postId);
		
		// 조회수 증가
		postMapper.increaseViewCount(postId);
		
		// 게시물 정보 조회
		return postMapper.getPostById(postId);
	}
	
	@Override
	public void writePost(PostVO post) {
		log.info("새 게시물 작성: " + post.getTitle());
		postMapper.insertPost(post);
	}
	
	@Override
	public void updatePost(PostVO post) {
		log.info("게시물 수정: " + post.getPostId());
		postMapper.updatePost(post);
	}
	
	@Override
	public void deletePost(int postId) {
		log.info("게시물 삭제: " + postId);
		postMapper.deletePost(postId);
	}
	
	@Override
	public List<PostVO> searchPosts(String keyword) {
		log.info("게시물 검색: " + keyword);
		return postMapper.searchPosts(keyword);
	}
	
	@Override
	public List<CommentVO> getComments(int postId) {
		log.info("댓글 목록 조회: " + postId);
		return commentMapper.getCommentsByPostId(postId);
	}
	
	@Override
	public void writeComment(CommentVO comment) {
		log.info("댓글 작성: " + comment.getPostId());
		commentMapper.insertComment(comment);
	}
	
	@Override
	public void deleteComment(int commentId) {
		log.info("댓글 삭제: " + commentId);
		commentMapper.deleteComment(commentId);
	}
	
	@Override
	public List<PostVO> getPostsWithPaging(String category, Criteria cri) {
	    log.info("페이징된 게시글 목록: " + category + ", 페이지: " + cri.getPageNum());
	    return postMapper.getPostsWithPaging(category, cri.getOffset(), cri.getAmount());
	}
	
	@Override
	public int getTotalCount(String category) {
	    log.info("전체 게시글 개수: " + category);
	    return postMapper.getTotalCount(category);
	}
}