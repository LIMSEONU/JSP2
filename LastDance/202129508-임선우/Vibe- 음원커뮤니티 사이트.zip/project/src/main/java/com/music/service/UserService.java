/**
 * ============================================
 * 파일명: UserService.java
 * 작성일: 2024-11-30
 * 작성자: 선우
 * 설명: 회원 관련 비즈니스 로직 인터페이스
 *      - 회원가입 및 로그인
 *      - 회원 정보 관리
 *      - 이메일 중복 체크
 * ============================================
 */
package com.music.service;

import com.music.domain.UserVO;

public interface UserService {
	
	// 회원가입
	public void registerUser(UserVO user);
	
	// 로그인 (이메일과 비밀번호 확인)
	public UserVO login(String email, String password);
	
	// 회원 정보 조회
	public UserVO getUserById(int userId);
	
	// 회원 정보 수정
	public void updateUser(UserVO user);
	
	// 회원 탈퇴
	public void deleteUser(int userId);
	
	// 이메일 중복 체크 (회원가입 시)
	public boolean isEmailDuplicate(String email);
}