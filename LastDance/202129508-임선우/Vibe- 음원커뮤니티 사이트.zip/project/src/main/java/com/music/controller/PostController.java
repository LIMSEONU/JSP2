/**
 * ============================================
 * 파일명: PostController.java
 * 작성일: 2024-11-26
 * 작성자: 선우
 * 설명: 게시판 관련 요청 처리 컨트롤러
 *      - 게시글 CRUD (등록/조회/수정/삭제)
 *      - 댓글 등록/삭제
 *      - 카테고리별 조회 및 페이징
 *      - 검색 기능
 * ============================================
 */
package com.music.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.music.domain.CommentVO;
import com.music.domain.Criteria;
import com.music.domain.PageDTO;
import com.music.domain.PostVO;
import com.music.domain.UserVO;
import com.music.service.PostService;

import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/board")
public class PostController {
	
	@Autowired
	private PostService postService;
	
	// 게시판 목록 (카테고리별, 페이징)
	@GetMapping("/list")
	public String list(@RequestParam(value = "category", defaultValue = "all") String category,
	                   Criteria cri,
	                   Model model) {
	    log.info("게시판 목록 - 카테고리: " + category + ", 페이지: " + cri.getPageNum());
	    
	    // 페이지당 5개씩 표시
	    cri.setAmount(5);
	    
	    // 페이징된 게시글 목록 조회
	    model.addAttribute("list", postService.getPostsWithPaging(category, cri));
	    model.addAttribute("category", category);
	    
	    // 페이징 정보 계산
	    int total = postService.getTotalCount(category);
	    model.addAttribute("pageMaker", new PageDTO(cri, total));
	    
	    return "project/board/list";
	}
	
	// 게시글 상세 조회
	@GetMapping("/get")
	public String get(@RequestParam("postId") int postId, Model model) {
		log.info("게시물 상세: " + postId);
		
		// 게시글 정보와 댓글 목록 조회
		model.addAttribute("post", postService.getPostById(postId));
		model.addAttribute("comments", postService.getComments(postId));
		return "project/board/get";
	}
	
	// 게시글 작성 페이지
	@GetMapping("/register")
	public String registerForm(HttpSession session) {
		log.info("게시물 작성 페이지");
		
		// 로그인 체크
		if(session.getAttribute("loginUser") == null) {
			return "redirect:/user/login";
		}
		
		return "project/board/register";
	}
	
	// 게시글 등록 처리
	@PostMapping("/register")
	public String register(PostVO post, HttpSession session, RedirectAttributes rttr) {
		log.info("게시물 작성: " + post.getTitle());
		
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		if(loginUser == null) {
			return "redirect:/user/login";
		}
		
		// 작성자 정보 설정 후 등록
		post.setUserId(loginUser.getUserId());
		postService.writePost(post);
		rttr.addFlashAttribute("message", "게시물이 등록되었습니다.");
		return "redirect:/board/list";
	}
	
	// 게시글 수정 페이지
	@GetMapping("/modify")
	public String modifyForm(@RequestParam("postId") int postId, HttpSession session, Model model) {
		log.info("게시물 수정 페이지: " + postId);
		
		if(session.getAttribute("loginUser") == null) {
			return "redirect:/user/login";
		}
		
		model.addAttribute("post", postService.getPostById(postId));
		return "project/board/modify";
	}
	
	// 게시글 수정 처리
	@PostMapping("/modify")
	public String modify(PostVO post, HttpSession session, RedirectAttributes rttr) {
		log.info("게시물 수정: " + post.getPostId());
		
		if(session.getAttribute("loginUser") == null) {
			return "redirect:/user/login";
		}
		
		postService.updatePost(post);
		rttr.addFlashAttribute("message", "게시물이 수정되었습니다.");
		return "redirect:/board/get?postId=" + post.getPostId();
	}
	
	// 게시글 삭제
	@PostMapping("/delete")
	public String delete(@RequestParam("postId") int postId, HttpSession session, RedirectAttributes rttr) {
		log.info("게시물 삭제: " + postId);
		
		if(session.getAttribute("loginUser") == null) {
			return "redirect:/user/login";
		}
		
		postService.deletePost(postId);
		rttr.addFlashAttribute("message", "게시물이 삭제되었습니다.");
		return "redirect:/board/list";
	}
	
	// 댓글 등록
	@PostMapping("/comment/register")
	public String writeComment(CommentVO comment, HttpSession session, RedirectAttributes rttr) {
		log.info("댓글 작성");
		
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		if(loginUser == null) {
			return "redirect:/user/login";
		}
		
		// 댓글 작성자 정보 설정 후 등록
		comment.setUserId(loginUser.getUserId());
		postService.writeComment(comment);
		rttr.addFlashAttribute("message", "댓글이 등록되었습니다.");
		return "redirect:/board/get?postId=" + comment.getPostId();
	}
	
	// 댓글 삭제
	@PostMapping("/comment/delete")
	public String deleteComment(@RequestParam("commentId") int commentId, 
								@RequestParam("postId") int postId, 
								HttpSession session, RedirectAttributes rttr) {
		log.info("댓글 삭제: " + commentId);
		
		if(session.getAttribute("loginUser") == null) {
			return "redirect:/user/login";
		}
		
		postService.deleteComment(commentId);
		rttr.addFlashAttribute("message", "댓글이 삭제되었습니다.");
		return "redirect:/board/get?postId=" + postId;
	}
	
	// 게시글 검색
	@GetMapping("/search")
	public String search(@RequestParam("keyword") String keyword, Model model) {
		log.info("게시물 검색: " + keyword);
		
		// 키워드로 게시글 검색
		model.addAttribute("list", postService.searchPosts(keyword));
		model.addAttribute("keyword", keyword);
		return "project/board/list";
	}
}