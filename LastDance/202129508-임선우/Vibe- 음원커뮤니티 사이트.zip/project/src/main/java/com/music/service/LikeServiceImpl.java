/**
 * ============================================
 * 파일명: LikeServiceImpl.java
 * 작성일: 2024-12-02
 * 작성자: 선우
 * 설명: 좋아요 관련 비즈니스 로직 구현 클래스
 *      - LikeService 인터페이스 구현
 *      - 좋아요 토글 및 통계 처리
 * ============================================
 */
package com.music.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.music.domain.SongVO;
import com.music.mapper.LikeMapper;

@Service
public class LikeServiceImpl implements LikeService {
    
    @Autowired
    private LikeMapper likeMapper;
    
    // 좋아요 토글 (추가/취소)
    @Override
    public boolean toggleLike(Integer userId, Integer songId) {
        // 이미 좋아요 되어있는지 확인
        if (likeMapper.isLiked(userId, songId) > 0) {
            // 좋아요 취소
            likeMapper.delete(userId, songId);
            return false;
        } else {
            // 좋아요 추가
            likeMapper.insert(userId, songId);
            return true;
        }
    }
    
    @Override
    public boolean isLiked(Integer userId, Integer songId) {
        return likeMapper.isLiked(userId, songId) > 0;
    }
    
    @Override
    public int getLikeCount(Integer songId) {
        return likeMapper.getLikeCount(songId);
    }
    
    @Override
    public List<SongVO> getLikedSongs(Integer userId) {
        return likeMapper.getLikedSongs(userId);
    }
    
    @Override
    public List<SongVO> getTopLikedSongs(int limit) {
        return likeMapper.getTopLikedSongs(limit);
    }
}