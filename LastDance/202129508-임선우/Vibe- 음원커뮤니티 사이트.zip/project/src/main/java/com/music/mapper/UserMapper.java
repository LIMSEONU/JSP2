/**
 * ============================================
 * 파일명: UserMapper.java
 * 작성일: 2024-11-29
 * 작성자: 선우
 * 설명: 회원 관련 데이터베이스 처리 매퍼 인터페이스
 *      - MyBatis를 통한 회원 CRUD 작업
 *      - 로그인 인증 처리
 *      - UserMapper.xml과 연동
 * ============================================
 */
package com.music.mapper;

import com.music.domain.UserVO;

public interface UserMapper {
	
	// 회원가입 - 새 회원 정보 DB에 저장
	public void insertUser(UserVO user);
	
	// 로그인 - 이메일로 회원 정보 조회
	public UserVO getUserByEmail(String email);
	
	// 회원 정보 수정
	public void updateUser(UserVO user);
	
	// 회원 탈퇴
	public void deleteUser(int userId);
	
	// 회원 ID로 회원 정보 조회
	public UserVO getUserById(int userId);
}