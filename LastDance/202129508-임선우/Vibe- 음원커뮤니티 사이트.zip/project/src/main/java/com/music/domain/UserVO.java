/**
 * ============================================
 * 파일명: UserVO.java
 * 작성일: 2024-11-28
 * 작성자: 선우
 * 설명: 회원 정보를 담는 VO (Value Object) 클래스
 *      - users 테이블과 매핑
 *      - 로그인 및 권한 관리
 * ============================================
 */
package com.music.domain;

import java.sql.Timestamp;
import lombok.Data;

@Data  // Lombok: getter, setter, toString 자동 생성
public class UserVO {
	private int userId;           // 회원 ID (PK)
	private String email;         // 이메일 (로그인 ID)
	private String password;      // 비밀번호 (암호화)
	private String username;      // 사용자 이름
    private String role;          // 권한 (admin/user)
	private String profileImage;  // 프로필 이미지 경로
	private Timestamp createdAt;  // 가입일
}