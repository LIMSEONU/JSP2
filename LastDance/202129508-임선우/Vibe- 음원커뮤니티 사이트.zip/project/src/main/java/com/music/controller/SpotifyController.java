/**
 * ============================================
 * 파일명: SpotifyController.java
 * 작성일: 2024-12-10
 * 작성자: 선우
 * 설명: Spotify API 검색 컨트롤러
 *      - 음원 등록 시 앨범 커버 및 메타데이터 검색
 *      - 관리자 전용 기능
 *      - JSON 형식으로 검색 결과 반환
 * ============================================
 */
package com.music.controller;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.google.gson.Gson;
import com.music.domain.UserVO;
import com.music.service.SpotifyService;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/spotify")
public class SpotifyController {
    
    @Autowired
    private SpotifyService spotifyService;
    
    // Spotify API 음원 검색 (관리자 전용, AJAX)
    @GetMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String search(@RequestParam("query") String query, HttpSession session) {
        log.info("Spotify 검색: " + query);
        
        // 관리자 권한 체크
        UserVO loginUser = (UserVO) session.getAttribute("loginUser");
        if (loginUser == null || !"admin".equals(loginUser.getRole())) {
            return "{\"success\": false, \"message\": \"권한이 없습니다\"}";
        }
        
        try {
            // Spotify API로 음원 검색 (제목, 아티스트, 앨범 커버 등)
            List<Map<String, Object>> tracks = spotifyService.searchTracks(query);
            
            // JSON 형식으로 변환하여 반환
            Gson gson = new Gson();
            String json = gson.toJson(tracks);
            
            return "{\"success\": true, \"tracks\": " + json + "}";
            
        } catch (Exception e) {
            log.error("Spotify 검색 실패", e);
            return "{\"success\": false, \"message\": \"검색 실패\"}";
        }
    }
}