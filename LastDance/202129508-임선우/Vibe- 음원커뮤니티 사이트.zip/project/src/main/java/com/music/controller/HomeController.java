/**
 * ============================================
 * 파일명: HomeController.java
 * 작성일: 2024-12-02
 * 작성자: 선우
 * 설명: 홈 페이지 관련 요청을 처리하는 컨트롤러
 *      - 메인 페이지 표시
 *      - 인기 음원 및 최신 음원 데이터 제공
 * ============================================
 */
package com.music.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.music.service.SongService;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
public class HomeController {
	
	// 음원 서비스 의존성 주입
	@Autowired
	private SongService songService;
	
	/**
	 * 홈 페이지 표시
	 * @param model 뷰에 전달할 데이터
	 * @return 홈 페이지 뷰
	 */
	@GetMapping("/")
	public String home(Model model) {
		log.info("메인 페이지");
		
		// 인기 음원 목록 조회 (재생 횟수 기준)
		model.addAttribute("topSongs", songService.getTopSongs());
		
		// 최신 음원 목록 조회 (등록일 기준)
		model.addAttribute("recentSongs", songService.getAllSongs());
		
		// 전체 곡 목록 추가 (하단 플레이어의 이전/다음 곡 재생용)
		model.addAttribute("allSongs", songService.getAllSongs());
		
		return "project/home";
	}
}