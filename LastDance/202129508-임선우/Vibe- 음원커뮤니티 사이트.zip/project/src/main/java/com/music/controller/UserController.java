/**
 * ============================================
 * 파일명: UserController.java
 * 작성일: 2024-11-26 (수정: 2024-12-02)
 * 작성자: 선우
 * 설명: 사용자 관련 요청 처리 컨트롤러
 *      - 로그인/로그아웃
 *      - 회원가입
 *      - 마이페이지 (좋아요한 음악 목록)
 * ============================================
 */
package com.music.controller;

import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.music.domain.SongVO;
import com.music.domain.UserVO;
import com.music.service.UserService;
import com.music.service.LikeService;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private LikeService likeService;
	
	// 로그인 페이지
	@GetMapping("/login")
	public String loginForm() {
		log.info("로그인 페이지");
		return "project/user/login";
	}
	
	// 로그인 처리
	@PostMapping("/login")
	public String login(UserVO user, HttpSession session, RedirectAttributes rttr) {
		log.info("로그인 시도: " + user.getEmail());
		
		// 이메일과 비밀번호로 사용자 인증
		UserVO loginUser = userService.login(user.getEmail(), user.getPassword());
		
		if (loginUser != null) {
			// 로그인 성공 - 세션에 사용자 정보 저장
			session.setAttribute("loginUser", loginUser);
			log.info("로그인 성공: " + loginUser.getUsername());
			return "redirect:/";
		} else {
			rttr.addFlashAttribute("error", "이메일 또는 비밀번호가 잘못되었습니다.");
			return "redirect:/user/login";
		}
	}
	
	// 로그아웃
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		log.info("로그아웃");
		// 세션 무효화
		session.invalidate();
		return "redirect:/";
	}
	
	// 회원가입 페이지
	@GetMapping("/register")
	public String registerForm() {
		log.info("회원가입 페이지");
		return "project/user/register";
	}
	
	// 회원가입 처리
	@PostMapping("/register")
	public String register(UserVO user, RedirectAttributes rttr) {
		log.info("회원가입: " + user.getEmail());
		
		try {
			userService.registerUser(user);
			rttr.addFlashAttribute("message", "회원가입이 완료되었습니다. 로그인해주세요.");
			return "redirect:/user/login";
		} catch (Exception e) {
			rttr.addFlashAttribute("error", "회원가입 실패: " + e.getMessage());
			return "redirect:/user/register";
		}
	}
	
	// 마이페이지 (좋아요한 음악 목록)
	@GetMapping("/mypage")
	public String mypage(HttpSession session, Model model, RedirectAttributes rttr) {
	    log.info("마이페이지");
	    
	    // 로그인 체크
	    UserVO loginUser = (UserVO) session.getAttribute("loginUser");
	    if (loginUser == null) {
	        rttr.addFlashAttribute("error", "로그인이 필요합니다.");
	        return "redirect:/user/login";
	    }
	    
	    // 사용자가 좋아요한 음악 목록 조회
	    List<SongVO> likedSongs = likeService.getLikedSongs(loginUser.getUserId());
	    model.addAttribute("likedSongs", likedSongs);
	    
	    log.info("좋아요한 곡 수: " + likedSongs.size());
	    
	    return "project/user/mypage";
	}
}