/**
 * ============================================
 * 파일명: PostMapper.java
 * 작성일: 2024-11-29
 * 작성자: 선우
 * 설명: 게시물 관련 데이터베이스 처리 매퍼 인터페이스
 *      - MyBatis를 통한 게시글 CRUD 작업
 *      - 카테고리별 조회 및 검색
 *      - 페이징 처리
 *      - PostMapper.xml과 연동
 * ============================================
 */
package com.music.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.music.domain.PostVO;

public interface PostMapper {
	
	// 전체 게시물 목록 조회 (최신순)
	public List<PostVO> getAllPosts();
	
	// 카테고리별 게시물 조회
	public List<PostVO> getPostsByCategory(String category);
	
	// 게시물 상세 조회
	public PostVO getPostById(int postId);
	
	// 새 게시물 작성
	public void insertPost(PostVO post);
	
	// 게시물 수정
	public void updatePost(PostVO post);
	
	// 게시물 삭제
	public void deletePost(int postId);
	
	// 조회수 증가
	public void increaseViewCount(int postId);
	
	// 게시물 검색 (제목+내용)
	public List<PostVO> searchPosts(String keyword);
	
	// 페이징된 게시글 목록 조회
	public List<PostVO> getPostsWithPaging(@Param("category") String category, 
	                                        @Param("offset") int offset, 
	                                        @Param("amount") int amount);
	
	// 전체 게시글 개수 (페이징 계산용)
	public int getTotalCount(@Param("category") String category);
}