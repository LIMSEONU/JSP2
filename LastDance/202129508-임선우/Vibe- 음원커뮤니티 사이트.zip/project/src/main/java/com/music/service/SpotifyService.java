/**
 * ============================================
 * 파일명: SpotifyService.java
 * 작성일: 2024-12-10
 * 작성자: 선우
 * 설명: Spotify API 연동 서비스 인터페이스
 *      - 음원 검색 (제목, 아티스트, 앨범 커버)
 *      - Access Token 관리
 * ============================================
 */
package com.music.service;

import java.util.List;
import java.util.Map;

public interface SpotifyService {
    
    // Spotify에서 곡 검색 (제목, 아티스트, 앨범 커버 등)
    public List<Map<String, Object>> searchTracks(String query);
    
    // Spotify API Access Token 갱신
    public String getAccessToken();
}