/**
 * ============================================
 * 파일명: SongVO.java
 * 작성일: 2024-11-28
 * 작성자: 선우
 * 설명: 음원 정보를 담는 VO 클래스
 *      - songs 테이블과 매핑
 *      - 음원 메타데이터 및 파일 경로 관리
 *      - Spotify API 연동 데이터 포함
 * ============================================
 */
package com.music.domain;

import java.sql.Timestamp;
import lombok.Data;

@Data
public class SongVO {
	private int songId;           // 곡 ID (PK)
	private String songTitle;     // 곡 제목
	private String artistName;    // 아티스트 이름
	private String albumTitle;    // 앨범 제목
	private int duration;         // 재생시간(초)
	private String filePath;      // 음원 파일 경로 (MP3)
	private String coverImage;    // 앨범 커버 이미지 경로 (Spotify URL 또는 로컬)
	private int playCount;        // 재생 횟수
	private Integer userId;       // 등록자 ID (FK)
	private Timestamp createdAt;  // 등록일
}