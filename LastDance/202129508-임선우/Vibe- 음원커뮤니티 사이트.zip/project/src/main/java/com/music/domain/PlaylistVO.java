/**
 * ============================================
 * 파일명: PlaylistVO.java
 * 작성일: 2024-11-28
 * 작성자: 선우
 * 설명: 플레이리스트 정보를 담는 VO 클래스
 *      - playlists 테이블과 매핑
 *      - 사용자별 음악 재생목록 관리
 * ============================================
 */
package com.music.domain;

import java.sql.Timestamp;
import lombok.Data;

@Data
public class PlaylistVO {
	private int playlistId;       // 플레이리스트 ID (PK)
	private int userId;           // 생성자 ID (FK)
	private String playlistName;  // 플레이리스트 이름
	private String description;   // 설명
	private Timestamp createdAt;  // 생성일
	
	// 조인용 추가 필드
	private String username;      // 생성자 이름
}