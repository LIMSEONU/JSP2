/**
 * ============================================
 * 파일명: SpotifyServiceImpl.java
 * 작성일: 2024-12-10
 * 작성자: 선우
 * 설명: Spotify API 연동 서비스 구현 클래스
 *      - SpotifyService 인터페이스 구현
 *      - Access Token 자동 갱신
 *      - 음원 검색 및 메타데이터 파싱
 * ============================================
 */
package com.music.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class SpotifyServiceImpl implements SpotifyService {
    
    // Spotify API 인증 정보
    private static final String CLIENT_ID = "e47844dc347c4ba59d2b0e4ed542c29c";
    private static final String CLIENT_SECRET = "e56f6c70e36e47c7810206e704a68a93";
    
    private String accessToken = null;
    private long tokenExpireTime = 0;
    
    // Access Token 발급 (만료 시 자동 갱신)
    @Override
    public String getAccessToken() {
        // 토큰이 유효하면 재사용
        if (accessToken != null && System.currentTimeMillis() < tokenExpireTime) {
            return accessToken;
        }
        
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost post = new HttpPost("https://accounts.spotify.com/api/token");
            
            // Client Credentials를 Base64로 인코딩
            String auth = CLIENT_ID + ":" + CLIENT_SECRET;
            String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
            
            post.setHeader("Authorization", "Basic " + encodedAuth);
            post.setHeader("Content-Type", "application/x-www-form-urlencoded");
            
            StringEntity entity = new StringEntity("grant_type=client_credentials");
            post.setEntity(entity);
            
            HttpResponse response = client.execute(post);
            String json = EntityUtils.toString(response.getEntity());
            
            // JSON 파싱하여 토큰 추출
            JsonObject jsonObject = JsonParser.parseString(json).getAsJsonObject();
            accessToken = jsonObject.get("access_token").getAsString();
            int expiresIn = jsonObject.get("expires_in").getAsInt();
            
            // 만료 시간 설정 (여유있게 5분 전으로)
            tokenExpireTime = System.currentTimeMillis() + ((expiresIn - 300) * 1000);
            
            log.info("Spotify Access Token 발급 성공");
            return accessToken;
            
        } catch (Exception e) {
            log.error("Spotify Access Token 발급 실패", e);
            return null;
        }
    }
    
    // Spotify에서 음원 검색
    @Override
    public List<Map<String, Object>> searchTracks(String query) {
        List<Map<String, Object>> tracks = new ArrayList<>();
        
        try {
            String token = getAccessToken();
            if (token == null) {
                log.error("Access Token이 없습니다");
                return tracks;
            }
            
            // 검색 쿼리 URL 인코딩
            String encodedQuery = java.net.URLEncoder.encode(query, "UTF-8");
            String url = "https://api.spotify.com/v1/search?q=" + encodedQuery + "&type=track&limit=10";
            
            try (CloseableHttpClient client = HttpClients.createDefault()) {
                HttpGet get = new HttpGet(url);
                get.setHeader("Authorization", "Bearer " + token);
                
                HttpResponse response = client.execute(get);
                String json = EntityUtils.toString(response.getEntity());
                
                // JSON 파싱
                JsonObject jsonObject = JsonParser.parseString(json).getAsJsonObject();
                JsonArray items = jsonObject.getAsJsonObject("tracks")
                                           .getAsJsonArray("items");
                
                // 검색 결과를 Map으로 변환
                for (JsonElement item : items) {
                    JsonObject track = item.getAsJsonObject();
                    
                    Map<String, Object> trackData = new HashMap<>();
                    
                    // 곡 제목
                    trackData.put("title", track.get("name").getAsString());
                    
                    // 아티스트 (첫 번째 아티스트)
                    JsonArray artists = track.getAsJsonArray("artists");
                    if (artists.size() > 0) {
                        trackData.put("artist", artists.get(0).getAsJsonObject()
                                                      .get("name").getAsString());
                    }
                    
                    // 앨범 제목
                    JsonObject album = track.getAsJsonObject("album");
                    trackData.put("album", album.get("name").getAsString());
                    
                    // 앨범 커버 이미지 URL
                    JsonArray images = album.getAsJsonArray("images");
                    if (images.size() > 0) {
                        trackData.put("coverImage", images.get(0).getAsJsonObject()
                                                         .get("url").getAsString());
                    }
                    
                    // 재생 시간 (밀리초 → 초 변환)
                    int durationMs = track.get("duration_ms").getAsInt();
                    trackData.put("duration", durationMs / 1000);
                    
                    // Spotify ID
                    trackData.put("spotifyId", track.get("id").getAsString());
                    
                    tracks.add(trackData);
                }
                
                log.info("Spotify 검색 성공: " + tracks.size() + "개");
                
            }
        } catch (Exception e) {
            log.error("Spotify 검색 실패", e);
        }
        
        return tracks;
    }
}