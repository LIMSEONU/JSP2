/**
 * ============================================
 * 파일명: PlaylistMapper.java
 * 작성일: 2024-11-29
 * 작성자: 선우
 * 설명: 플레이리스트 관련 데이터베이스 처리 매퍼 인터페이스
 *      - MyBatis를 통한 플레이리스트 CRUD 작업
 *      - 플레이리스트-음원 관계 관리
 *      - PlaylistMapper.xml과 연동
 * ============================================
 */
package com.music.mapper;

import java.util.List;
import com.music.domain.PlaylistVO;
import com.music.domain.SongVO;

public interface PlaylistMapper {
	
	// 특정 사용자의 플레이리스트 목록 조회
	public List<PlaylistVO> getPlaylistsByUserId(int userId);
	
	// 플레이리스트 상세 정보 조회
	public PlaylistVO getPlaylistById(int playlistId);
	
	// 새 플레이리스트 생성
	public void insertPlaylist(PlaylistVO playlist);
	
	// 플레이리스트 정보 수정
	public void updatePlaylist(PlaylistVO playlist);
	
	// 플레이리스트 삭제
	public void deletePlaylist(int playlistId);
	
	// 플레이리스트에 곡 추가 (다대다 관계)
	public void addSongToPlaylist(int playlistId, int songId);
	
	// 플레이리스트에서 곡 제거
	public void removeSongFromPlaylist(int playlistId, int songId);
	
	// 플레이리스트의 곡 목록 조회
	public List<SongVO> getSongsInPlaylist(int playlistId);
}