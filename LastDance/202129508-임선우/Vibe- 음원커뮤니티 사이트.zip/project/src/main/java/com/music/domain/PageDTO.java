/**
 * ============================================
 * 파일명: PageDTO.java
 * 작성일: 2024-12-02
 * 작성자: 선우
 * 설명: 페이지 네비게이션 정보를 담는 DTO
 *      - 페이지 번호 범위 계산 (1~10, 11~20...)
 *      - 이전/다음 버튼 표시 여부 결정
 * ============================================
 */
package com.music.domain;

import lombok.Data;

@Data
public class PageDTO {
    private int startPage;   // 시작 페이지 번호
    private int endPage;     // 끝 페이지 번호
    private boolean prev;    // 이전 버튼 표시 여부
    private boolean next;    // 다음 버튼 표시 여부
    
    private int total;       // 전체 게시물 수
    private Criteria cri;    // 현재 페이지 정보
    
    public PageDTO(Criteria cri, int total) {
        this.cri = cri;
        this.total = total;
        
        // 끝 페이지 번호 계산 (10개씩 표시: 1~10, 11~20...)
        this.endPage = (int) (Math.ceil(cri.getPageNum() / 10.0)) * 10;
        
        // 시작 페이지 번호
        this.startPage = this.endPage - 9;
        
        // 실제 마지막 페이지 계산 (전체 게시물 수 기준)
        int realEnd = (int) (Math.ceil((total * 1.0) / cri.getAmount()));
        
        // 실제 끝 페이지가 더 작으면 조정
        if (realEnd < this.endPage) {
            this.endPage = realEnd;
        }
        
        // 이전/다음 버튼 표시 여부
        this.prev = this.startPage > 1;
        this.next = this.endPage < realEnd;
    }
}