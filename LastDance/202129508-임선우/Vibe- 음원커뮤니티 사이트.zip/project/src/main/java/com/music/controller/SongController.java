/**
 * ============================================
 * 파일명: SongController.java
 * 작성일: 2024-11-26 (수정: 2024-12-05)
 * 작성자: 선우
 * 설명: 음원 관련 요청 처리 컨트롤러
 *      - 음원 CRUD (등록/조회/수정/삭제)
 *      - MP3 파일 업로드
 *      - 페이징 및 검색
 *      - 재생 횟수 카운팅
 *      - 관리자 권한 제어
 * ============================================
 */
package com.music.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.music.domain.SongVO;
import com.music.domain.UserVO;
import com.music.domain.Criteria;
import com.music.domain.PageDTO;
import com.music.service.SongService;
import com.music.service.LikeService;

import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/song")
public class SongController {
	
	@Autowired
	private SongService songService;
	
	@Autowired
	private LikeService likeService;
	
	// 음원 목록 (페이징)
	@GetMapping("/list")
	public String list(Criteria cri, Model model) {
		log.info("음원 목록 - 페이지: " + cri.getPageNum());
		
		// 페이징된 음원 목록
		model.addAttribute("list", songService.getSongsWithPaging(cri));
		
		// 전체 곡 목록 (하단 플레이어용)
		model.addAttribute("allSongs", songService.getAllSongs());
		
		// 페이징 정보 계산
		int total = songService.getTotalCount();
		model.addAttribute("pageMaker", new PageDTO(cri, total));
		
		return "project/song/list";
	}
	
	// 음원 상세 조회
	@GetMapping("/get")
	public String get(@RequestParam("songId") int songId, Model model, HttpSession session) {
		log.info("음원 상세: " + songId);
		model.addAttribute("song", songService.getSongById(songId));
		
		// 좋아요 정보 조회
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		if (loginUser != null) {
			boolean isLiked = likeService.isLiked(loginUser.getUserId(), songId);
			model.addAttribute("isLiked", isLiked);
		}
		int likeCount = likeService.getLikeCount(songId);
		model.addAttribute("likeCount", likeCount);
		
		return "project/song/get";
	}
	
	// 음원 등록 페이지 (관리자 전용)
	@GetMapping("/register")
	public String registerForm(HttpSession session, RedirectAttributes rttr) {
		log.info("음원 등록 페이지");
		
		// 관리자 권한 체크
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		if (loginUser == null) {
			rttr.addFlashAttribute("error", "로그인이 필요합니다.");
			return "redirect:/user/login";
		}
		if (!"admin".equals(loginUser.getRole())) {
			rttr.addFlashAttribute("error", "관리자만 음원을 등록할 수 있습니다.");
			return "redirect:/song/list";
		}
		
		return "project/song/register";
	}
	
	// 음원 등록 처리 (MP3 파일 업로드)
	@PostMapping("/register")
	public String register(SongVO song, 
	                      @RequestParam("file") MultipartFile file,
	                      RedirectAttributes rttr, 
	                      HttpSession session) {
		log.info("음원 등록: " + song.getSongTitle());
		
		// 관리자 권한 체크
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		if (loginUser == null || !"admin".equals(loginUser.getRole())) {
			rttr.addFlashAttribute("error", "권한이 없습니다.");
			return "redirect:/song/list";
		}
		
		try {
			// MP3 파일 업로드 처리
			if (!file.isEmpty()) {
				String originalFilename = file.getOriginalFilename();
				String extension = originalFilename.substring(originalFilename.lastIndexOf("."));
				String savedFilename = System.currentTimeMillis() + extension;
				
				// 서버에 파일 저장
				String uploadPath = session.getServletContext().getRealPath("/resources/music/");
				File uploadDir = new File(uploadPath);
				if (!uploadDir.exists()) {
					uploadDir.mkdirs();
				}
				
				File savedFile = new File(uploadPath + savedFilename);
				file.transferTo(savedFile);
				
				song.setFilePath("/resources/music/" + savedFilename);
				log.info("파일 저장 완료: " + savedFilename);
			} else {
				rttr.addFlashAttribute("error", "MP3 파일을 선택해주세요.");
				return "redirect:/song/register";
			}
			
			song.setUserId(loginUser.getUserId());
			songService.registerSong(song);
			rttr.addFlashAttribute("message", "음원이 등록되었습니다.");
			return "redirect:/song/list";
			
		} catch (Exception e) {
			log.error("음원 등록 실패", e);
			rttr.addFlashAttribute("error", "음원 등록에 실패했습니다.");
			return "redirect:/song/register";
		}
	}
	
	// 음원 수정 페이지
	@GetMapping("/modify")
	public String modifyForm(@RequestParam("songId") int songId, Model model, 
	                         HttpSession session, RedirectAttributes rttr) {
		log.info("음원 수정 페이지: " + songId);
		
		// 관리자 권한 체크
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		if (loginUser == null || !"admin".equals(loginUser.getRole())) {
			rttr.addFlashAttribute("error", "권한이 없습니다.");
			return "redirect:/song/list";
		}
		
		model.addAttribute("song", songService.getSongById(songId));
		return "project/song/modify";
	}
	
	// 음원 수정 처리
	@PostMapping("/modify")
	public String modify(SongVO song, RedirectAttributes rttr, HttpSession session) {
		log.info("음원 수정: " + song.getSongId());
		
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		if (loginUser == null || !"admin".equals(loginUser.getRole())) {
			rttr.addFlashAttribute("error", "권한이 없습니다.");
			return "redirect:/song/list";
		}
		
		songService.updateSong(song);
		rttr.addFlashAttribute("message", "음원이 수정되었습니다.");
		return "redirect:/song/get?songId=" + song.getSongId();
	}
	
	// 음원 삭제
	@PostMapping("/delete")
	public String delete(@RequestParam("songId") int songId, RedirectAttributes rttr, HttpSession session) {
		log.info("음원 삭제: " + songId);
		
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		if (loginUser == null || !"admin".equals(loginUser.getRole())) {
			rttr.addFlashAttribute("error", "권한이 없습니다.");
			return "redirect:/song/list";
		}
		
		songService.deleteSong(songId);
		rttr.addFlashAttribute("message", "음원이 삭제되었습니다.");
		return "redirect:/song/list";
	}
	
	// 음원 재생 (재생 횟수 증가)
	@PostMapping("/play")
	public String play(@RequestParam("songId") int songId) {
		log.info("음원 재생: " + songId);
		songService.playSong(songId);
		return "redirect:/song/get?songId=" + songId;
	}
	
	// 음원 검색 (제목/아티스트/앨범)
	@GetMapping("/search")
	public String search(@RequestParam("keyword") String keyword, Model model) {
	    log.info("=== 음원 검색 시작 ===");
	    log.info("검색어: " + keyword);
	    
	    List<SongVO> searchResults = songService.searchSongs(keyword);
	    
	    log.info("검색 결과 수: " + searchResults.size());
	    if (searchResults.isEmpty()) {
	        log.warn("검색 결과가 없습니다!");
	    } else {
	        for (SongVO song : searchResults) {
	            log.info("- " + song.getSongTitle() + " by " + song.getArtistName());
	        }
	    }
	    
	    model.addAttribute("list", searchResults);
	    model.addAttribute("keyword", keyword);
	    
	    return "project/song/list";
	}
}