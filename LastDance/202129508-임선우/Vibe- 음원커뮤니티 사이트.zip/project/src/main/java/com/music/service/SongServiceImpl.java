/**
 * ============================================
 * 파일명: SongServiceImpl.java
 * 작성일: 2024-11-30
 * 작성자: 선우
 * 설명: 음원 관련 비즈니스 로직 구현 클래스
 *      - SongService 인터페이스 구현
 *      - 음원 CRUD 및 검색 처리
 * ============================================
 */
package com.music.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.music.domain.Criteria;
import com.music.domain.SongVO;
import com.music.mapper.SongMapper;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class SongServiceImpl implements SongService {
	
	@Autowired
	private SongMapper songMapper;
	
	@Override
	public List<SongVO> getAllSongs() {
		log.info("전체 음원 목록 조회");
		return songMapper.getAllSongs();
	}
	
	@Override
	public List<SongVO> getSongsWithPaging(Criteria cri) {
	    log.info("페이징된 음원 목록: " + cri.getPageNum());
	    return songMapper.getSongsWithPaging(cri.getOffset(), cri.getAmount());
	}
	
	@Override
	public int getTotalCount() {
	    log.info("전체 음원 개수 조회");
	    return songMapper.getTotalCount();
	}
	
	@Override
	public SongVO getSongById(int songId) {
		log.info("음원 상세 조회: " + songId);
		return songMapper.getSongById(songId);
	}
	
	@Override
	public void registerSong(SongVO song) {
		log.info("새 음원 등록: " + song.getSongTitle());
		songMapper.insertSong(song);
	}
	
	@Override
	public void updateSong(SongVO song) {
		log.info("음원 정보 수정: " + song.getSongId());
		songMapper.updateSong(song);
	}
	
	@Override
	public void deleteSong(int songId) {
		log.info("음원 삭제: " + songId);
		songMapper.deleteSong(songId);
	}
	
	@Override
	public List<SongVO> searchSongs(String keyword) {
		log.info("음원 검색: " + keyword);
		return songMapper.searchSongs(keyword);
	}
	
	@Override
	public void playSong(int songId) {
		log.info("음원 재생: " + songId);
		// 재생 횟수 증가
		songMapper.increasePlayCount(songId);
	}
	
	@Override
	public List<SongVO> getTopSongs() {
		log.info("인기 음원 Top 10 조회");
		return songMapper.getTopSongs();
	}
}