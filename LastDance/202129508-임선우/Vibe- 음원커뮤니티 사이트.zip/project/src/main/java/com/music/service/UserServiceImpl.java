/**
 * ============================================
 * 파일명: UserServiceImpl.java
 * 작성일: 2024-11-30
 * 작성자: 선우
 * 설명: 회원 관련 비즈니스 로직 구현 클래스
 *      - UserService 인터페이스 구현
 *      - 로그인 인증 처리
 *      - 이메일 중복 체크
 * ============================================
 */
package com.music.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.music.domain.UserVO;
import com.music.mapper.UserMapper;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserMapper userMapper;
	
	@Override
	public void registerUser(UserVO user) {
		log.info("회원가입: " + user.getEmail());
		userMapper.insertUser(user);
	}
	
	// 로그인 (이메일과 비밀번호 검증)
	@Override
	public UserVO login(String email, String password) {
		log.info("로그인 시도: " + email);
		
		// 이메일로 회원 정보 조회
		UserVO user = userMapper.getUserByEmail(email);
		
		// 회원이 없거나 비밀번호가 틀리면 null 반환
		if(user == null || !user.getPassword().equals(password)) {
			log.warn("로그인 실패: " + email);
			return null;
		}
		
		log.info("로그인 성공: " + email);
		return user;
	}
	
	@Override
	public UserVO getUserById(int userId) {
		log.info("회원 정보 조회: " + userId);
		return userMapper.getUserById(userId);
	}
	
	@Override
	public void updateUser(UserVO user) {
		log.info("회원 정보 수정: " + user.getUserId());
		userMapper.updateUser(user);
	}
	
	@Override
	public void deleteUser(int userId) {
		log.info("회원 탈퇴: " + userId);
		userMapper.deleteUser(userId);
	}
	
	// 이메일 중복 체크
	@Override
	public boolean isEmailDuplicate(String email) {
		log.info("이메일 중복 체크: " + email);
		UserVO user = userMapper.getUserByEmail(email);
		return user != null;  // 이미 존재하면 true
	}
}