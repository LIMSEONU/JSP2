/**
 * ============================================
 * 파일명: PostService.java
 * 작성일: 2024-11-30
 * 작성자: 선우
 * 설명: 게시물 관련 비즈니스 로직 인터페이스
 *      - 게시글 CRUD 및 검색
 *      - 댓글 관리
 *      - 카테고리별 조회 및 페이징
 * ============================================
 */
package com.music.service;

import java.util.List;
import com.music.domain.PostVO;
import com.music.domain.CommentVO;
import com.music.domain.Criteria;

public interface PostService {
	
	// 전체 게시물 목록 조회
	public List<PostVO> getAllPosts();
	
	// 카테고리별 게시물 조회
	public List<PostVO> getPostsByCategory(String category);
	
	// 게시물 상세 조회 (조회수 자동 증가)
	public PostVO getPostById(int postId);
	
	// 새 게시물 작성
	public void writePost(PostVO post);
	
	// 게시물 수정
	public void updatePost(PostVO post);
	
	// 게시물 삭제
	public void deletePost(int postId);
	
	// 게시물 검색 (제목+내용)
	public List<PostVO> searchPosts(String keyword);
	
	// 특정 게시물의 댓글 목록 조회
	public List<CommentVO> getComments(int postId);
	
	// 댓글 작성
	public void writeComment(CommentVO comment);
	
	// 댓글 삭제
	public void deleteComment(int commentId);
	
	// 페이징된 게시글 목록 조회
	public List<PostVO> getPostsWithPaging(String category, Criteria cri);
	
	// 전체 게시글 개수 (페이징 계산용)
	public int getTotalCount(String category);
}